<?php
/**
 * Includes all Templates Files
 */
function drz_includes_required_files() {
    
    require DRZ_MAIN.'header.php';
    require DRZ_MAIN.'slider-section.php';
    require DRZ_MAIN.'products.php';
    require DRZ_MAIN.'includes/functions.php';
    // require DRZ_MAIN.'sign-up.php';
}
drz_includes_required_files();